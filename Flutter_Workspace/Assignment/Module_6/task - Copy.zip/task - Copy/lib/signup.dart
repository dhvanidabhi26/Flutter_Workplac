import 'package:flutter/material.dart';
import 'package:task/authication.dart';
import 'package:task/chatscreen.dart';
import 'package:task/login_screen.dart';

class Signup extends StatefulWidget {
  const Signup({super.key});

  @override
  State<Signup> createState() => _SignupState();
}

class _SignupState extends State<Signup> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();

  final _formKey = GlobalKey<FormState>();

  bool _doPasswordsMatch() {
    return _passwordController.text == _confirmPasswordController.text;
  }

  void _signUp() async {
    try {
      await AuthenticationService().signUpUser(
        _emailController.text,
        _passwordController.text,
      );
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => Homepage(userEmail: _emailController.text),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(e.toString()),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    double displayHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      body: ListView(
        padding: const EdgeInsets.all(26.0),
        children: [
          SizedBox(height: 100),
          Icon(
            Icons.message,
            size: 90,
            color: Colors.deepPurple,
          ),
          SizedBox(height: 18),
          Center(
            child: Text(
              "Chatter",
              style: TextStyle(
                color: Colors.deepPurple,
                fontSize: 25,
                letterSpacing: 1,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          SizedBox(height: 20),
          Form(
            key: _formKey,
            child: Column(
              children: [
                TextFormField(
                  controller: _emailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(60)),
                    hintText: "Enter Email",
                    prefixIcon: Icon(Icons.email_outlined, color: Colors.deepPurple[900]),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter an email';
                    }
                    return null;
                  },
                ),
                SizedBox(height: 15),
                TextFormField(
                  controller: _passwordController,
                  obscureText: true,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(60)),
                    hintText: "Enter Password",
                    prefixIcon: Icon(Icons.lock, color: Colors.deepPurple[900]),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter a password';
                    }
                    return null;
                  },
                ),
                SizedBox(height: 15),
                TextFormField(
                  controller: _confirmPasswordController,
                  obscureText: true,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(60)),
                    hintText: "Confirm Password",
                    prefixIcon: Icon(Icons.lock, color: Colors.deepPurple[900]),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please confirm your password';
                    }
                    return null;
                  },
                ),
                SizedBox(height: 15),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(foregroundColor: Colors.white,
                    backgroundColor: Colors.deepPurple,
                    padding: EdgeInsets.symmetric(horizontal: 120, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(25),
                    ),
                    elevation: 5,
                  ),
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      if (!_doPasswordsMatch()) {
                        showDialog(
                          context: context,
                          builder: (context) => AlertDialog(
                            title: const Text("Error"),
                            content: const Text("Passwords do not match"),
                            actions: <Widget>[
                              TextButton(
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                                child: const Text("OK"),
                              ),
                            ],
                          ),
                        );
                      } else {
                        _signUp();
                      }
                    }
                  },
                  child: Text(
                    "REGISTER",
                    style: TextStyle(color: Colors.white),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextButton(
                      onPressed: () {
                        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>LoginPage()));
                      },
                      child: Text(
                        "Already have an account? Click here!",
                        style: TextStyle(color: Colors.deepPurple),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 100,),
                Padding(
                  padding: const EdgeInsets.only(left: 60),
                  child: Row(
                    children: [
                      Text("Made with",style: TextStyle(color: Colors.black,fontSize: 14),),
                      Icon(Icons.favorite,color: Colors.red),
                      Text("by dhvanidabhi",style: TextStyle(color: Colors.black,fontSize: 14),),
                    ],
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
