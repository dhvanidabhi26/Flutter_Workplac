import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:task/auth_servicce.dart';
import 'package:task/authication.dart';
import 'package:task/signup.dart';


class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  // Controllers
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();


  // Form key
  final _formKey = GlobalKey<FormState>();

  // Google Sign-In instance
  final GoogleSignIn _googleSignIn = GoogleSignIn(scopes: ['email']);

  // Sign in with email and password
  void _signIn() async
  {
    try {
      await AuthenticationService().signInUser(
        _emailController.text,
        _passwordController.text,
      );
      _goToAuth();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );
    }
  }

  // Navigate to authentication check
  void _goToAuth() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => AuthCheck()),
    );
  }

  @override
  Widget build(BuildContext context)
  {
    double displayHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      body: ListView(
        padding:  EdgeInsets.all(26.0),
        children: [
          SizedBox(height: displayHeight / 6),
          Icon(Icons.message, size: 90,color: Colors.deepPurple,),
          SizedBox(height: 18),
          Center(
            child: Text(
                "Chatter",
                style: TextStyle(
                  color: Colors.deepPurple,
                  fontSize: 25,
                  letterSpacing: 1,
                  fontWeight: FontWeight.bold,
                )
            ),
          ),
          SizedBox(height: 20),
          Form(
            key: _formKey,
            child: Column(
              children:
              [
                TextFormField(
                    controller: _emailController,
                    keyboardType: TextInputType.emailAddress,
                    decoration: InputDecoration
                      (
                      border: OutlineInputBorder(borderRadius:BorderRadius.circular(60)),
                      hintText: "Enter Email",
                      prefixIcon: Icon(Icons.email_outlined,color: Colors.deepPurple[900],),
                    )
                ),
                SizedBox(height: 12),

                TextFormField(
                  controller: _passwordController,
                  obscureText:true,
                  decoration: InputDecoration
                    (
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(60)),
                    hintText: "Enter Password",
                    prefixIcon: Icon(Icons.lock,color: Colors.deepPurple[900],),

                  ),
                ),
                SizedBox(height: 12),

                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    foregroundColor: Colors.white,
                    backgroundColor: Colors.deepPurple,
                    padding: EdgeInsets.symmetric(horizontal: 120, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(25),
                    ),
                    elevation: 5,
                  ),
                  onPressed: ()
                  {
                    if (_formKey.currentState!.validate()) {
                      _signIn();
                    }
                  },
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children:
                    [
                      SizedBox(width: 8),
                      Text("LOGIN",style: TextStyle(color: Colors.white),),
                    ],
                  ),
                ),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const Signup(),
                          ),
                        );
                      },
                      child: Text(
                        "Don't have an account? Click here!",
                        style: TextStyle(
                            color:Colors.deepPurple
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 100,),
                Padding(
                  padding: const EdgeInsets.only(left: 60),
                  child: Row(
                    children: [
                      Text("Made with",style: TextStyle(color: Colors.black,fontSize: 14),),
                      Icon(Icons.favorite,color: Colors.red),
                      Text("by dhvanidabhi",style: TextStyle(color: Colors.black,fontSize: 14),),
                    ],
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}