import 'package:flutter/material.dart';
import 'package:task/login_screen.dart';
import 'package:task/signup.dart';


class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {


  @override
  Widget build(BuildContext context)
  {
    double displayHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      body: ListView(
        padding:  EdgeInsets.all(26.0),
        children: [
          SizedBox(height: displayHeight / 6),
          Icon(Icons.message, size: 90,color: Colors.deepPurple,),
          SizedBox(height: 18),
          Center(
            child: Column(
              children: [
                Text(
                    "Chatter",
                    style: TextStyle(
                      color: Colors.deepPurple,
                      fontSize: 25,
                      letterSpacing: 1,
                      fontWeight: FontWeight.bold,
                    )
                ),
                Text(
                    "WORLD'S MOST PRIVATE CHATTING APP",
                    style: TextStyle(
                      color: Colors.deepPurple,
                      fontSize: 12,
                      letterSpacing: 1,
                      fontWeight: FontWeight.bold,
                    )
                ),
                SizedBox(height: 130,),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    foregroundColor: Colors.white,
                    backgroundColor: Colors.deepPurple,
                    padding: EdgeInsets.symmetric(horizontal: 120, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(25), // Rounded corners
                    ),
                    elevation: 5,
                  ),
                  onPressed: () {
                    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>LoginPage()));
                  },
                  child: Text(
                    "LOGIN",
                    style: TextStyle(color: Colors.white),
                  ),
                ),
                SizedBox(height: 10),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    foregroundColor: Colors.white,
                    backgroundColor: Colors.deepPurple,
                    padding: EdgeInsets.symmetric(horizontal: 120, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(25),
                    ),
                    elevation: 5,
                  ),
                  onPressed: () {
                    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>Signup()));
                  },
                  child: Text(
                    "SIGNUP",
                    style: TextStyle(color: Colors.white),
                  ),
                ),
                SizedBox(height: 100,),
                Padding(
                  padding: const EdgeInsets.only(left: 60),
                  child: Row(
                    children: [
                      Text("Made with",style: TextStyle(color: Colors.black,fontSize: 14),),
                      Icon(Icons.favorite,color: Colors.red),
                      Text("by dhvanidabhi",style: TextStyle(color: Colors.black,fontSize: 14),),
                    ],
                  ),
                )
              ],
            ),

          ),
          SizedBox(height: 20),
        ],
      ),
    );
  }
}