import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:task/chatscreen.dart';
import 'package:task/login_screen.dart';

class AuthCheck extends StatelessWidget {
  const AuthCheck({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.active) {
            if (snapshot.hasData) {
              User? user = snapshot.data;
              String userEmail = user!.email ?? '';
              return Homepage(userEmail: userEmail);
            } else {
              // User is not logged in
              return LoginPage();
            }
          } else {
            // Show a loading indicator while waiting for authentication state
            return Center(child: CircularProgressIndicator());
          }
        },
      ),
    );
  }
}
