package com.example.travel_guidance

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
